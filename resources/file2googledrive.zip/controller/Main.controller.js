sap.ui.define(["./BaseController", "../model/formatter", "sap/ui/unified/FileUploaderParameter", "sap/m/MessageToast"], function (__BaseController, __formatter, FileUploaderParameter, MessageToast) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const formatter = _interopRequireDefault(__formatter);
  /**
   * @namespace miyasuta.file2googledrive.controller
   */
  const Main = BaseController.extend("miyasuta.file2googledrive.controller.Main", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.formatter = formatter;
    },
    handleUploadPress: async function _handleUploadPress() {
      const oFileUploader = this.byId("fileUploader");
      await oFileUploader.checkFileReadable();

      //set headers
      oFileUploader.removeAllHeaderParameters();
      const fileName = oFileUploader.getValue();
      oFileUploader.addHeaderParameter(new FileUploaderParameter({
        name: "filename",
        value: fileName
      }));
      oFileUploader.upload();
    },
    handleUploadComplete: function _handleUploadComplete(oEvent) {
      const iHttpStatusCode = oEvent.getParameter("status");
      let sMessage;
      if (iHttpStatusCode) {
        sMessage = iHttpStatusCode === 200 ? "Upload Success" : "Upload Error";
        MessageToast.show(sMessage);
      }
    }
  });
  return Main;
});